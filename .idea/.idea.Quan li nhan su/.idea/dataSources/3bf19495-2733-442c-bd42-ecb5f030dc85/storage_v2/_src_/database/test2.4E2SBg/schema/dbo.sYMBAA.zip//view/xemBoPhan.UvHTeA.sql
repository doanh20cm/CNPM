create view xemBoPhan as
select BoPhan.MaBoPhan, BoPhan.TenBoPhan, BoPhan.NgayThanhLap, SDTBoPhan, BoPhan.GhiChu, count(PhongBan.MaPhongBan) as 'Số phòng ban hiện có'

from BoPhan left join PhongBan on BoPhan.MaBoPhan = PhongBan.MaBoPhan

group by BoPhan.MaBoPhan, BoPhan.TenBoPhan, BoPhan.NgayThanhLap, BoPhan.GhiChu, SDTBoPhan
go

